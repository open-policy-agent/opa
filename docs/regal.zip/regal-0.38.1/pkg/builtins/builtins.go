package builtins

import (
	_ "github.com/open-policy-agent/regal/pkg/builtins/opa"
	_ "github.com/open-policy-agent/regal/pkg/builtins/regal"
)
