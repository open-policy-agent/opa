//go:build regal_standalone

package mode

const Standalone = true
