//go:build !regal_enable_novelty

package novelty

func HappyHolidays() error { return nil }
