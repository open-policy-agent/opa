### [foo.bar](https://example.com)

```rego
output := foo.bar(arg1, arg2)
```

Description for Foo Bar


#### Arguments

- `arg1` string — arg1 for foobar
- `arg2` string — arg2 for foobar


Returns `output` of type `number`: the output for foobar
