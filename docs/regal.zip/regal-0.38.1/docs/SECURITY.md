# Security Policy

Please refer to the [OPA Security Policy](https://www.openpolicyagent.org/security)
for details on how to report security issues, our disclosure policy, and how to
receive notifications about security issues.
