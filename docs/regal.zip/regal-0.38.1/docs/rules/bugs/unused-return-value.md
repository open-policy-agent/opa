---
draft: true
---

# unused-return-value

## Please Note

This rule has been renamed to
[_unassigned-return-value_](https://www.openpolicyagent.org/projects/regal/rules/bugs/unassigned-return-value).
