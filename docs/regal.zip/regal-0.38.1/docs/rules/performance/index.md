# Performance

Rules to help identify possible performance issues.

import RulesTable from '@site/src/components/projects/regal/RulesTable';

<!-- markdownlint-disable MD033 -->
<RulesTable category="performance"/>
