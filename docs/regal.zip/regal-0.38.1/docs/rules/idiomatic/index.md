# Idiomatic

Rules that enforce idiomatic code.

import RulesTable from '@site/src/components/projects/regal/RulesTable';

<!-- markdownlint-disable MD033 -->
<RulesTable category="idiomatic"/>
