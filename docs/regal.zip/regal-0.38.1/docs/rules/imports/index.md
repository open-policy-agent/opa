# Imports

Rules related to importing of packages and keywords.

import RulesTable from '@site/src/components/projects/regal/RulesTable';

<!-- markdownlint-disable MD033 -->
<RulesTable category="imports"/>
