# Testing

Rules relading to Rego tests.

import RulesTable from '@site/src/components/projects/regal/RulesTable';

<!-- markdownlint-disable MD033 -->
<RulesTable category="testing"/>
