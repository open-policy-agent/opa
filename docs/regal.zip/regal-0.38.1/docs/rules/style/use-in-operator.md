# use-in-operator

## Please Note

This rule has been moved to the
[_idiomatic_ category](https://www.openpolicyagent.org/projects/regal/rules/idiomatic/use-in-operator).
