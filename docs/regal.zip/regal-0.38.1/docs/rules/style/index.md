# Style

Rules relating to code style.

import RulesTable from '@site/src/components/projects/regal/RulesTable';

<!-- markdownlint-disable MD033 -->
<RulesTable category="style"/>
