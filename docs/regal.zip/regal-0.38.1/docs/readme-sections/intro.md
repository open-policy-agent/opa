<!-- markdownlint-disable MD041 -->

Regal is a linter, debugger and language server for [Rego](https://www.openpolicyagent.org/docs/policy-language/),
making your Rego magnificent, and you the ruler of rules!

With its extensive set of linter rules, documentation and editor integrations, Regal is the perfect companion for policy
development, whether you're an experienced Rego developer or just starting out.
